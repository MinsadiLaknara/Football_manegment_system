package com.company;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.time.LocalDate;

import static org.junit.Assert.*;

public class DateTest {
    LocalDate localDate = LocalDate.of(2010, 5, 30);
    Date date = new Date(localDate);


    @Test
    public void getDate() {
        Assertions.assertEquals(localDate,date.getDate());
    }

    @Test
    public void setDate() {
        LocalDate localDate01 = LocalDate.of(2010, 8, 20);
        date.setDate(localDate01);
        Assertions.assertEquals(localDate01, date.getDate());
    }
}