package com.company;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import static org.junit.Assert.*;

public class FootballClubTest {

    @Test
    public void getWin_count() {
        Assertions.assertEquals(1,1);
    }

    @Test
    public void setWin_count() {
        Assertions.assertEquals(2,2);
    }

    @Test
    public void getDraws_count() {
        Assertions.assertEquals(6,6);
    }

    @Test
    public void setDraws_count() {
        Assertions.assertEquals(9,9);
    }

    @Test
    public void getDefeats_count() {
        Assertions.assertEquals(5,5);
    }

    @Test
    public void setDefeats_count() {
        Assertions.assertEquals(3,3);
    }

    @Test
    public void getScoredGoal_count() {
        Assertions.assertEquals(4,4);
    }

    @Test
    public void setScoredGoal_count() {
        Assertions.assertEquals(5,5);
    }

    @Test
    public void getReceivedGoal_count() {
        Assertions.assertEquals(5,5);
    }

    @Test
    public void setReceivedGoal_count() {
        Assertions.assertEquals(8,8);
    }

    @Test
    public void getCurrent_point() {
        Assertions.assertEquals(7,7);
    }

    @Test
    public void setCurrent_point() {
        Assertions.assertEquals(7,7);
    }

    @Test
    public void getPlayedMatch_count() {
        Assertions.assertEquals(2,2);
    }

    @Test
    public void setPlayedMatch_count() {
        Assertions.assertEquals(2,2);
    }

    @Test
    public void getDifference_Goal() {
        Assertions.assertEquals(11,11);
    }

    @Test
    public void setDifference_Goal() {
        Assertions.assertEquals(10,10);
    }
}