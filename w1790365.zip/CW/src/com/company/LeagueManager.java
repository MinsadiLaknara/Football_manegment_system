package com.company;

public interface LeagueManager {
    void display_LeagueTable();
    void play_Match();
    void display_Statistics();
    void delete_team();
    void add_team();



}
