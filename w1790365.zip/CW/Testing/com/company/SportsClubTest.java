package com.company;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import static org.junit.Assert.*;

public class SportsClubTest {

    @Test
    public void getSclub_name() {
        Assertions.assertEquals("minsi","minsi");

    }

    @Test
    public void setSclub_name() {
        Assertions.assertEquals("minsi","minsi");

    }

    @Test
    public void setSclub_location() {
        Assertions.assertEquals("navinna","navinna");
    }

    @Test
    public void getSclub_location() {
        Assertions.assertEquals("navinna","navinna");
    }
}