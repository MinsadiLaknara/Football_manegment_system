package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        PremierLeagueManager premierLeagueManager = new PremierLeagueManager(10);
        premierLeagueManager.displayMenu();
    }
}
