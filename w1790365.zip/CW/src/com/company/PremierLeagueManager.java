package com.company;



import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class PremierLeagueManager implements LeagueManager {
    private final int numOfClubs;
    private ArrayList<FootballClub> club_record = new ArrayList<>();
    private ArrayList<Match> num_match = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public  PremierLeagueManager(int numOfClubs){
        this.numOfClubs = numOfClubs;
        displayMenu();
    }


    // creating method
    //displaying menu method
    public void displayMenu() {
        File file = new File("D:\\CW\\Data of club.txt");
        if(file.exists()){
            fileReader();
        }
        File file1 = new File("D:\\CW\\Date.txt");
        if(file1.exists()){
            fileReader1();
        }
        while (true) {
            System.out.println("Main menu : ");
            System.out.println("Enter 1 : To create a new Football team");
            System.out.println("Enter 2 : To Delete a new Football team");
            System.out.println("Enter 3 : To Display Statistics for team");
            System.out.println("Enter 4 : To Display the PremierLeague table");
            System.out.println("Enter 5 : To Add a played match");
            System.out.println("Enter 6 : To write the file");
            System.out.println("Enter 7 : To open the GUI");
            System.out.println("Enter 8 : To Exit");
            String input = sc.nextLine();
            int selection = 0;
            try {
                selection = Integer.parseInt(input);
            } catch (Exception e) {

            }
            switch (selection) {
                case 1:
                    add_team();
                    break;
                case 2:
                    delete_team();
                    break;
                case 3:
                    display_Statistics();
                    break;
                case 4:
                    display_LeagueTable();
                    break;
                case 5:
                    play_Match();
                    break;
                case 6:
                    fileWriter();
                    fileWriter1();
                    break;
                case 7:
                    fileWriter();
                    fileWriter1();
                    GUI();
                    fileReader();
                    fileReader1();
                    break;
                case 8:
                    break;
                default:
                    System.out.println("wrong selection");

            }
        }
    }

    //adding up a new team method
    @Override
    public void add_team() {
        if (club_record.size() == numOfClubs) {
            System.out.println("Can't enter any more the maximum count of clubs has reached");
            return;
        }
        FootballClub club = new FootballClub();
        System.out.println("Enter a club name");
        String input = sc.nextLine();
        club.setSclub_name(input);

        if(club_record.contains(club)){
            System.out.println("This club is already added");
            return;
        }
        System.out.println("Enter the club location");
        input = sc.nextLine();
        club.setSclub_location(input);
        club_record.add(club);
    }

    //deleting a exiting team method
    @Override
    public void delete_team(){
        System.out.println("Enter a Club name which you want to delete");
        String input = sc.nextLine();
        for (FootballClub club: club_record){
            if(club.getSclub_name().equals(input)){
                club_record.remove(club);
                System.out.println(club.getSclub_name() + "club have been deleted successfully  ");
                return;
            }
        }
        System.out.println("This name is new to the club");
    }
    //displaying statistics method
    @Override
    public void display_Statistics() {
        System.out.println("Enter the club name");
        String input = sc.nextLine();
        for (FootballClub club : club_record) {
            if (club.getSclub_name().equals(input)) {
                System.out.println(club.getSclub_name() + "  club won Matches : " + club.getWin_count());
                System.out.println(club.getSclub_name() + "  club failed Matches : " + club.getDefeats_count());
                System.out.println(club.getSclub_name() + "  club draw Matches : " + club.getDraws_count());
                System.out.println(club.getSclub_name() + "  club scored Matches : " + club.getScoredGoal_count());
                System.out.println(club.getSclub_name() + "  club received Matches : " + club.getReceivedGoal_count());
                System.out.println(club.getSclub_name() + "  club current points : " + club.getCurrent_point());
                System.out.println(club.getSclub_name() + "  club Matches played: " + club.getPlayedMatch_count());
                return;
            }
        }
        System.out.println("Error : couldn't find in the records");

    }
    //displaying the league Table
    @Override
    public void display_LeagueTable(){
        Collections.sort(club_record, new Order());
        for(FootballClub club : club_record) {
            System.out.println(club.getSclub_name() + "  club points :  "+club.getCurrent_point()+"  Played Matches :  "+club.getPlayedMatch_count()+ "  Won count:  " +club.getWin_count()+"  Draw points:  "+club.getDraws_count()+
                    "  Defeat points  : "+club.getDefeats_count()+"  Received Goal count  : "+club.getReceivedGoal_count()+
                    "  Scored Goal count:  "+club.getScoredGoal_count() +"  goal difference:  "
                    +(club.getScoredGoal_count()-club.getReceivedGoal_count()));
        }
    }
    //play match method
    @Override
    public void play_Match() {
        if(club_record.size()<2){
            System.out.println("2 clubs are required to Play a Match");
            return;
        }
        Collections.shuffle(club_record);
        Random random = new Random();
        Scanner sc = new Scanner(System.in);
        Match match = new Match();

        while (true) {
            try {
                System.out.print("Enter the Match Day :");
                int day = sc.nextInt();
                if (day > 30 || day < 1) {
                    System.out.println("Enter a Day between 1 - 30 ");
                    continue;
                }
                System.out.print("Enter the Match Month :");
                int month = sc.nextInt();
                if (month > 12 || month < 1) {
                    System.out.println("Enter a Day between 1 - 12 ");
                    continue;
                }
                System.out.print("Enter the Match Year :");
                int year = sc.nextInt();
                if (year > 2030 || year < 2020) {
                    System.out.println("Enter a Day between 2020 - 2030 ");
                    continue;
                }
                LocalDate localDate = LocalDate.of(year,month,day);
                Date date = new Date(localDate);

                int j = 0;
                int teama_Goal = 0;
                int teamb_Goal = 0;
                String winner = null;
                int count = 0;

                //selecting teams randomly to play a match
                for (FootballClub club : club_record) {
                    j++;
                    if (j == 1) {
                        String teamOne;
                        teamOne = club.getSclub_name();
                        match.setTeam_X_name(teamOne);
                        teama_Goal = random.nextInt(11);
                    } else if (j == 2) {
                        String teamTwo;
                        teamTwo = club.getSclub_name();
                        match.setTeam_Y_name(teamTwo);
                        teamb_Goal = random.nextInt(11);
                        break;

                    }

                }
                match.setDate(date);
                Match match1 = new Match(match.getTeam_X_name(), match.getTeam_Y_name(), match.getTeam_X_GoalCount(), match.getTeam_Y_GoalCount(), match.getDate());
                num_match.add(match1);



                if (teama_Goal > teamb_Goal) {
                    club_record.get(0).setWin_count(club_record.get(0).getWin_count() + 1);
                    club_record.get(0).setReceivedGoal_count(club_record.get(0).getReceivedGoal_count() + teamb_Goal);
                    club_record.get(0).setScoredGoal_count(club_record.get(0).getScoredGoal_count() + teama_Goal);
                    club_record.get(0).setCurrent_point(club_record.get(0).getCurrent_point() + 1);
                    club_record.get(0).setPlayedMatch_count(club_record.get(0).getPlayedMatch_count() + 1);
                    winner = club_record.get(0).getSclub_name();

                    club_record.get(1).setDefeats_count(club_record.get(1).getDefeats_count() + 1);
                    club_record.get(1).setReceivedGoal_count(club_record.get(1).getReceivedGoal_count() + teama_Goal);
                    club_record.get(1).setScoredGoal_count(club_record.get(1).getScoredGoal_count() + teamb_Goal);
                    club_record.get(1).setPlayedMatch_count(club_record.get(1).getPlayedMatch_count() + 1);

                } else if (teama_Goal < teamb_Goal) {
                    club_record.get(1).setWin_count(club_record.get(1).getWin_count() + 1);
                    club_record.get(1).setReceivedGoal_count(club_record.get(1).getReceivedGoal_count() + teamb_Goal);
                    club_record.get(1).setScoredGoal_count(club_record.get(1).getScoredGoal_count() + teama_Goal);
                    club_record.get(1).setCurrent_point(club_record.get(1).getCurrent_point() + 1);
                    club_record.get(1).setPlayedMatch_count(club_record.get(1).getPlayedMatch_count() + 1);
                    winner = club_record.get(1).getSclub_name();

                    club_record.get(0).setDefeats_count(club_record.get(0).getDefeats_count() + 1);
                    club_record.get(0).setReceivedGoal_count(club_record.get(0).getReceivedGoal_count() + teama_Goal);
                    club_record.get(0).setScoredGoal_count(club_record.get(0).getScoredGoal_count() + teamb_Goal);
                    club_record.get(0).setPlayedMatch_count(club_record.get(0).getPlayedMatch_count() + 1);
                }
                else {
                    club_record.get(0).setDraws_count(club_record.get(0).getDraws_count() + 1);
                    club_record.get(0).setReceivedGoal_count(club_record.get(0).getReceivedGoal_count() + teamb_Goal);
                    club_record.get(0).setScoredGoal_count(club_record.get(0).getScoredGoal_count() + teama_Goal);
                    club_record.get(0).setPlayedMatch_count(club_record.get(0).getPlayedMatch_count() + 1);

                    club_record.get(1).setDraws_count(club_record.get(1).getDraws_count() + 1);
                    club_record.get(1).setDraws_count(club_record.get(1).getDraws_count() + 1);
                    club_record.get(1).setReceivedGoal_count(club_record.get(1).getReceivedGoal_count() + teama_Goal);
                    club_record.get(1).setScoredGoal_count(club_record.get(1).getScoredGoal_count() + teamb_Goal);
                    club_record.get(1).setPlayedMatch_count(club_record.get(1).getPlayedMatch_count() + 1);
                    count++;
                }
                //Displaying the stat of the Match
                System.out.println("\n"+club_record.get(0).getSclub_name()+ "Vs" +club_record.get(1).getSclub_name());
                System.out.println("Date :" +match.getDate());
                System.out.println("Team One Goal :"+teama_Goal);
                System.out.println("Team Two Goal :"+teamb_Goal);

                if(count==1){
                    System.out.println("Draw");
                }
                else{
                    System.out.println("Winner :"+winner);
                }
                club_record.sort(FootballClub::compareTo);
                break;


            } catch (InputMismatchException e) {
                System.out.println("Please enter the Integer :" +e);
                sc.nextLine();

            }

        }
    }


    //file handing methods
    private void fileWriter(){
        try{
            FileOutputStream writeData = new FileOutputStream("Data of club.txt");
            ObjectOutputStream writer = new ObjectOutputStream(writeData);

            writer.writeObject(club_record);
            writer.flush();
            writer.close();


        }catch (IOException e){
            e.printStackTrace();
        }
    }
    private void fileReader(){
        try {
            FileInputStream readData = new FileInputStream("Data of club.txt");
            ObjectInputStream reader = new ObjectInputStream(readData);

            ArrayList<FootballClub> club_record1 = (ArrayList<FootballClub>) reader.readObject();
            reader.close();
            club_record = club_record1;
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void fileWriter1() {
        try {
            FileOutputStream writer_Data = new FileOutputStream("Date.txt");
            ObjectOutputStream writer_Stream = new ObjectOutputStream(writer_Data);

            writer_Stream.writeObject(num_match);
            writer_Stream.flush();
            writer_Stream.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    private void fileReader1(){
        try{
            FileInputStream read_Data = new FileInputStream("Date.txt");
            ObjectInputStream read_Stream = new ObjectInputStream(read_Data);

            ArrayList<Match> num_match1 = (ArrayList<Match>) read_Stream.readObject();
            read_Stream.close();
            num_match = num_match1;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void GUI(){
        GUI.main(null);
    }


}



