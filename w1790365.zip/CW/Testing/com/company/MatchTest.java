package com.company;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.time.LocalDate;

import static org.junit.Assert.*;

public class MatchTest {
    LocalDate localDate = LocalDate.of(2020,4,16);
    Date date = new Date(localDate);
    Match match = new Match("JPURA","IIT",9,7,date);

    @Test
    public void getTeam_X_name() {
        Assertions.assertEquals("JPURA",match.getTeam_X_name());
    }

    @Test
    public void setTeam_X_name() {
        match.setTeam_X_name("IIT");
        Assertions.assertEquals("IIT",match.getTeam_Y_name());
    }

    @Test
    public void getTeam_Y_name() {
        Assertions.assertEquals("IIT",match.getTeam_Y_name());
    }

    @Test
    public void setTeam_Y_name() {
        match.setTeam_Y_name("NSBM");
        Assertions.assertEquals("NSBM",match.getTeam_Y_name());
    }

    @Test
    public void getTeam_X_GoalCount() {
        Assertions.assertEquals(9,match.getTeam_X_GoalCount());
    }

    @Test
    public void setTeam_X_GoalCount() {
        match.setTeam_X_GoalCount(7);
        Assertions.assertEquals(7,match.getTeam_X_GoalCount());
    }

    @Test
    public void getTeam_Y_GoalCount() {
        Assertions.assertEquals(7,match.getTeam_Y_GoalCount());
    }

    @Test
    public void setTeam_Y_GoalCount() {
        match.setTeam_Y_GoalCount(10);
        Assertions.assertEquals(10,match.getTeam_Y_GoalCount());
    }

    @Test
    public void getDate() {
        Assertions.assertEquals(date,match.getDate());
    }

    @Test
    public void setDate() {
        LocalDate localDate1 = LocalDate.of(2005,8,11);
        Date date1 = new Date(localDate1);
        match.setDate(date1);
        Assertions.assertEquals(date1,match.getDate());
    }
}