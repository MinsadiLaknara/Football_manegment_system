package com.company;

import java.io.Serializable;

public abstract class SportsClub implements Serializable {

    private String Sclub_name;
    private String Sclub_location;


    public String getSclub_name() {
        return Sclub_name;
    }

    public void setSclub_name(String sclub) {
        this.Sclub_name = sclub;
    }

    public void setSclub_location(String sclub) {
        this.Sclub_location = sclub;
    }

    public String getSclub_location() {
        return Sclub_location;
    }

    @Override
    public boolean equals(Object obj) {
        return this.Sclub_name.equals(((SportsClub)obj).Sclub_name);
    }

}
