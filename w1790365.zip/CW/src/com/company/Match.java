package com.company;

import java.io.Serializable;

public class Match implements Serializable {
    private String team_X_name;
    private String team_Y_name;
    private int team_X_GoalCount;
    private int team_Y_GoalCount;
    private Date date;

    public Match() {

    }

    public Match(String team_X_name, String team_Y_name, int team_X_GoalCount, int team_Y_GoalCount, Date date) {
        this.team_X_name = team_X_name;
        this.team_Y_name = team_Y_name;
        this.team_X_GoalCount = team_X_GoalCount;
        this.team_Y_GoalCount = team_Y_GoalCount;
        this.date = date;
    }

    public String getTeam_X_name() {
        return team_X_name;
    }

    public void setTeam_X_name(String team_X_name) {
        this.team_X_name = team_X_name;
    }

    public String getTeam_Y_name() {
        return team_Y_name;
    }

    public void setTeam_Y_name(String team_Y_name) {
        this.team_Y_name = team_Y_name;
    }

    public int getTeam_X_GoalCount() {
        return team_X_GoalCount;
    }

    public void setTeam_X_GoalCount(int team_X_GoalCount) {
        this.team_X_GoalCount = team_X_GoalCount;
    }

    public int getTeam_Y_GoalCount() {
        return team_Y_GoalCount;
    }

    public void setTeam_Y_GoalCount(int team_Y_GoalCount) {
        this.team_Y_GoalCount = team_Y_GoalCount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Match{" +
                "team_X_name='" + team_X_name + '\'' +
                ", team_Y_name='" + team_Y_name + '\'' +
                ", team_X_GoalCount='" + team_X_GoalCount + '\'' +
                ", team_Y_GoalCount='" + team_Y_GoalCount + '\'' +
                ", date=" +date +
                '}';
    }
}

