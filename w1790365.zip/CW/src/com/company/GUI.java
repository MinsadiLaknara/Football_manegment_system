package com.company;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;

import java.awt.*;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;

import java.io.*;
import java.util.*;
import java.time.LocalDate;

public class GUI extends Application {
    Scene scene, scene1;
    private ArrayList<FootballClub> club_record = new ArrayList<>();
    private ArrayList<Match> num_match = new ArrayList<>();
    TableView<Object> table_content = new TableView<>();
    TableView<Object> table_content1 = new TableView<>();
    ObservableList<Object> observableList1 = FXCollections.observableArrayList();
    ObservableList<Object> observableList2 = FXCollections.observableArrayList();
    ObservableList<Object> observableList3 = FXCollections.observableArrayList();

    //file writer and reader separately for two arraylist club_record and num_match
    private void GUI_fileWriter() {
        try {
            FileOutputStream writingData = new FileOutputStream("Data of club.txt");
            ObjectOutputStream writingStream = new ObjectOutputStream(writingData);

            writingStream.writeObject(club_record);
            writingStream.flush();
            writingStream.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    private void GUI_fileWriter1() {
        try {
            FileOutputStream writing_Data = new FileOutputStream("Date.txt");
            ObjectOutputStream writing_Stream = new ObjectOutputStream(writing_Data);

            writing_Stream.writeObject(num_match);
            writing_Stream.flush();
            writing_Stream.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }


    private void GUI_fileReader() {
        try{
            FileInputStream readingData = new FileInputStream("Data of club.txt");
            ObjectInputStream readingStream = new ObjectInputStream(readingData);

            ArrayList<FootballClub> sportList1 = (ArrayList<FootballClub>) readingStream.readObject();
            readingStream.close();
            club_record = sportList1;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void GUI_fileReading1(){
        try{
            FileInputStream reading_Data = new FileInputStream("Date.txt");
            ObjectInputStream reading_Stream = new ObjectInputStream(reading_Data);

            ArrayList<Match> ArrayMatch1 = (ArrayList<Match>) reading_Stream.readObject();
            reading_Stream.close();
            num_match = ArrayMatch1;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        GUI_fileReader();
        GUI_fileReading1();
        primaryStage.setTitle("Premier League");

        Image img = new Image("file:football.jpg");
        ImageView imageView = new ImageView();
        ImageView imageView1 = new ImageView();
        imageView.setFitHeight(1000);
        imageView.setFitWidth(1250);
        imageView.setImage(img);
        imageView1.setImage(img);
        imageView.setPreserveRatio(true);


        TableColumn<Object, String> sportsClubname_column = new TableColumn<>("Club Name");
        sportsClubname_column.setCellValueFactory(new PropertyValueFactory<>("Sclub_name"));
        sportsClubname_column.setMinWidth(190);

        TableColumn<Object, Integer> PlayedMatches_column = new TableColumn<>("Played\nMatches");
        PlayedMatches_column.setCellValueFactory(new PropertyValueFactory<>("playedMatch_count"));
        PlayedMatches_column.setMinWidth(50);

        TableColumn<Object, Integer> WinsCount_column = new TableColumn<>("Wins");
        WinsCount_column.setCellValueFactory(new PropertyValueFactory<>("win_count"));
        WinsCount_column.setMinWidth(50);

        TableColumn<Object, Integer> DrawCount_Column = new TableColumn<>("Draws");
        DrawCount_Column.setCellValueFactory(new PropertyValueFactory<>("draws_count"));
        DrawCount_Column.setMinWidth(50);

        TableColumn<Object, Integer> DefeatCount_column = new TableColumn<>("Defeats");
        DefeatCount_column.setCellValueFactory(new PropertyValueFactory<>("defeats_count"));
        DefeatCount_column.setMinWidth(50);

        TableColumn<Object, Integer> ReceivedGoals_column = new TableColumn<>("Received\nGoals");
        ReceivedGoals_column.setCellValueFactory(new PropertyValueFactory<>("receivedGoal_count"));
        ReceivedGoals_column.setMinWidth(50);

        TableColumn<Object, Integer> ScoredGoals_column = new TableColumn<>("Scored\nGoals");
        ScoredGoals_column.setCellValueFactory(new PropertyValueFactory<>("scoredGoal_count"));
        ScoredGoals_column.setMinWidth(50);

        TableColumn<Object, Integer> Point_column = new TableColumn<>("Points");
        Point_column.setCellValueFactory(new PropertyValueFactory<>("current_point"));
        Point_column.setMinWidth(50);

        //scene 1 table 1
        observableList1.addAll(club_record);
        table_content.setLayoutX(450);
        table_content.setLayoutY(50);
        table_content.getColumns().addAll(sportsClubname_column, PlayedMatches_column,Point_column,WinsCount_column,DrawCount_Column,DefeatCount_column, ScoredGoals_column, ReceivedGoals_column);
        table_content.setItems(observableList1);
        table_content.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        //button for goal count
        Button btn1 = new Button("Goal count");
        btn1.setLayoutX(300);
        btn1.setLayoutY(250);
        btn1.setPrefSize(130, 30);
        btn1.setStyle("-fx-background-color: #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-border-color: #654321;" +
                "-fx-font-weight: bold;");
        btn1.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn1.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn1.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn1.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScoredGoals_column.setSortType(TableColumn.SortType.DESCENDING);
                table_content.getSortOrder().addAll(ScoredGoals_column);
            }
        });


        //button for Win count
        Button btn2 = new Button("Win count");
        btn2.setLayoutX(300);
        btn2.setLayoutY(300);
        btn2.setPrefSize(130, 30);
        btn2.setStyle("-fx-background-color: #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-border-color: #654321;" +
                "-fx-font-weight: bold;");
        btn2.setOnMousePressed((new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn2.setStyle("-fx-background-color:#FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        }));

        btn2.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn2.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                WinsCount_column.setSortType(TableColumn.SortType.DESCENDING);
                table_content.getSortOrder().addAll(WinsCount_column);
            }
        });

        //button for Date View
        Button btn3 = new Button("Date View");
        btn3.setLayoutX(300);
        btn3.setLayoutY(400);
        btn3.setPrefSize(130, 30);
        btn3.setStyle("-fx-background-color:  #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-border-color: #654321;" +
                "-fx-font-weight: bold;");
        btn3.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn3.setStyle("-fx-background-color:  #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn3.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn3.setStyle("-fx-background-color:  #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene1);
                File file1 = new File("Date.txt");
                if (file1.exists()) {
                    GUI_fileReading1();
                    for (int n = 0; n < table_content1.getItems().size(); n++) {
                        table_content1.getItems().clear();
                    }
                    observableList2.addAll(num_match);
                    table_content1.setItems(observableList2);
                }
            }
        });


        //button for goal count
        Button btn4 = new Button("Save");
        btn4.setLayoutX(300);
        btn4.setLayoutY(350);
        btn4.setPrefSize(130, 30);
        btn4.setStyle("-fx-background-color: #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-border-color: #654321;" +
                "-fx-font-weight: bold;");
        btn4.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn4.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn4.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn4.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-border-color: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                GUI_fileWriter();
                GUI_fileWriter1();
            }
        });

        //Labels for Text area
        Label day = new Label("Enter Match Day :");
        day.setLayoutX(100);
        day.setLayoutY(50);
        day.setStyle("-fx-font-weight: bold;"+
                "-fx-text-fill: #FFC0CB;");

        //text Field for day
        TextField textday = new TextField();
        textday.setLayoutX(250);
        textday.setLayoutY(50);

        Label month = new Label("Enter Match Month :");
        month.setLayoutX(100);
        month.setLayoutY(100);
        month.setStyle("-fx-font-weight: bold;"+
                "-fx-text-fill: #FFC0CB;");


        //text Field for month
        TextField textmonth = new TextField();
        textmonth.setLayoutX(250);
        textmonth.setLayoutY(100);

        Label year = new Label("Enter Match Year :");
        year.setLayoutX(100);
        year.setLayoutY(150);
        year.setStyle("-fx-font-weight: bold;"+
                "-fx-text-fill: #FFC0CB;");

        //text Field for year
        TextField textyear = new TextField();
        textyear.setLayoutX(250);
        textyear.setLayoutY(150);

        //label to display the status of the random match
        Label status = new Label();
        status.setLayoutX(25);
        status.setLayoutY(225);
        status.setStyle("-fx-font-weight: bold;"+
                "-fx-text-fill: #FFC0CB;"+"-fx-border-color: white;");

        //laber to display the winner
        Label winnerbtn = new Label();
        winnerbtn.setLayoutX(25);
        winnerbtn.setLayoutY(250);
        winnerbtn.setStyle("-fx-font-weight: bold;"+
                "-fx-text-fill: #FFC0CB;");


        //Label for play match

        Button btn5 = new Button("Play");
        btn5.setLayoutX(10);
        btn5.setLayoutY(105);
        btn5.setPrefSize(80, 30);
        btn5.setStyle("-fx-background-color: #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-font-weight: bold;");
        btn5.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn5.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn5.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn5.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        btn5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (club_record.size() < 2) {
                    System.out.println("2 Clubs are Required to Play a Match");
                    return;
                }
                Collections.shuffle(club_record);
                Random random = new Random();
                Scanner sc = new Scanner(System.in);
                Match match = new Match();

                while (true) {
                    try {
                        //alerts for day,month,year
                        if (textday.getText().isEmpty() || Integer.parseInt(textday.getText()) > 30 || Integer.parseInt(textday.getText()) < 1) {
                            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                            alert1.setTitle("Information Dialog");
                            alert1.setHeaderText("Error Information");
                            alert1.setContentText("Enter Day Between 1 to 30");

                            alert1.showAndWait();
                            break;
                        }
                        if (textmonth.getText().isEmpty() || Integer.parseInt(textmonth.getText()) > 12 || Integer.parseInt(textmonth.getText()) < 1) {
                            Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
                            alert2.setTitle("Information Dialog");
                            alert2.setHeaderText("Error Information");
                            alert2.setContentText("Enter Month Between 1 to 12");

                            alert2.showAndWait();
                            break;
                        }
                        if (textyear.getText().isEmpty() || Integer.parseInt(textyear.getText()) > 2022 || Integer.parseInt(textyear.getText()) < 2020) {
                            Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
                            alert2.setTitle("Information Dialog");
                            alert2.setHeaderText("Error Information");
                            alert2.setContentText("Enter Year Between 2020 to 2022");

                            alert2.showAndWait();
                            break;

                        }
                        LocalDate localDate = LocalDate.of(Integer.parseInt(textyear.getText()), Integer.parseInt(textmonth.getText()), Integer.parseInt(textday.getText()));
                        Date date = new Date(localDate);

                        int j = 0;
                        int teama_Goal = 0;
                        int teamb_Goal = 0;
                        String winner = null;
                        int count = 0;

                        //selecting teams and randomly playing matches
                        for (FootballClub club : club_record) {
                            j++;
                            if (j == 1) {
                                String teamOne;
                                teamOne = club.getSclub_name();
                                match.setTeam_X_name(teamOne);
                                teama_Goal = random.nextInt(11);
                                match.setTeam_X_GoalCount(teama_Goal);
                            } else if (j == 2) {
                                String teamTwo;
                                teamTwo = club.getSclub_name();
                                match.setTeam_Y_name(teamTwo);
                                teamb_Goal = random.nextInt(11);
                                match.setTeam_Y_GoalCount(teamb_Goal);
                                break;

                            }

                        }
                        match.setDate(date);
                        Match match1 = new Match(match.getTeam_X_name(), match.getTeam_Y_name(), match.getTeam_X_GoalCount(), match.getTeam_Y_GoalCount(), match.getDate());
                        num_match.add(match1);

                        //array list contained with stat
                        club_record.get(0).setDifference_Goal(club_record.get(0).getDifference_Goal() + (teama_Goal - teamb_Goal));
                        club_record.get(1).setDifference_Goal(club_record.get(1).getDifference_Goal() + (teama_Goal - teamb_Goal));

                        if (teama_Goal > teamb_Goal) {
                            club_record.get(0).setWin_count(club_record.get(0).getWin_count() + 1);
                            club_record.get(0).setReceivedGoal_count(club_record.get(0).getReceivedGoal_count() + teamb_Goal);
                            club_record.get(0).setScoredGoal_count(club_record.get(0).getScoredGoal_count() + teama_Goal);
                            club_record.get(0).setCurrent_point(club_record.get(0).getCurrent_point() + 1);
                            club_record.get(0).setPlayedMatch_count(club_record.get(0).getPlayedMatch_count() + 1);
                            winner = club_record.get(0).getSclub_name();

                            club_record.get(1).setDefeats_count(club_record.get(1).getDefeats_count() + 1);
                            club_record.get(1).setReceivedGoal_count(club_record.get(1).getReceivedGoal_count() + teama_Goal);
                            club_record.get(1).setScoredGoal_count(club_record.get(1).getScoredGoal_count() + teamb_Goal);
                            club_record.get(1).setPlayedMatch_count(club_record.get(1).getPlayedMatch_count() + 1);

                        } else if (teama_Goal < teamb_Goal) {
                            club_record.get(1).setWin_count(club_record.get(1).getWin_count() + 1);
                            club_record.get(1).setReceivedGoal_count(club_record.get(1).getReceivedGoal_count() + teamb_Goal);
                            club_record.get(1).setScoredGoal_count(club_record.get(1).getScoredGoal_count() + teama_Goal);
                            club_record.get(1).setCurrent_point(club_record.get(1).getCurrent_point() + 1);
                            club_record.get(1).setPlayedMatch_count(club_record.get(1).getPlayedMatch_count() + 1);
                            winner = club_record.get(1).getSclub_name();

                            club_record.get(0).setDefeats_count(club_record.get(0).getDefeats_count() + 1);
                            club_record.get(0).setReceivedGoal_count(club_record.get(0).getReceivedGoal_count() + teama_Goal);
                            club_record.get(0).setScoredGoal_count(club_record.get(0).getScoredGoal_count() + teamb_Goal);
                            club_record.get(0).setPlayedMatch_count(club_record.get(0).getPlayedMatch_count() + 1);
                        }
                        else {
                            club_record.get(0).setDraws_count(club_record.get(0).getDraws_count() + 1);
                            club_record.get(0).setReceivedGoal_count(club_record.get(0).getReceivedGoal_count() + teamb_Goal);
                            club_record.get(0).setScoredGoal_count(club_record.get(0).getScoredGoal_count() + teama_Goal);
                            club_record.get(0).setPlayedMatch_count(club_record.get(0).getPlayedMatch_count() + 1);


                            club_record.get(1).setDraws_count(club_record.get(1).getDraws_count() + 1);
                            club_record.get(1).setReceivedGoal_count(club_record.get(1).getReceivedGoal_count() + teama_Goal);
                            club_record.get(1).setScoredGoal_count(club_record.get(1).getScoredGoal_count() + teamb_Goal);
                            club_record.get(1).setPlayedMatch_count(club_record.get(1).getPlayedMatch_count() + 1);
                            count++;
                        }
                        //printing a dialog separatly to show the clubs which are played randomly and the winner
                        status.setText("Status of the match\n\n" + "\nDate of played match : " + match.getDate() +"\n"+ club_record.get(0).getSclub_name() + " Vs " + club_record.get(1).getSclub_name() +
                                "\nTeam A Goals : " + teamb_Goal + "\nTeam B Goals : " + teama_Goal);

                        if (count == 1) {
                            winnerbtn.setText("\nMatch Draw");
                        } else {
                            winnerbtn.setText("\nThe Winner is: " + winner);
                        }
                        club_record.sort(FootballClub::compareTo);

                        for (int n = 0; n < table_content.getItems().size(); n++) {
                            table_content.getItems().clear();
                        }
                        observableList1.addAll(club_record);
                        table_content.setItems(observableList1);
                        break;

                    } catch (InputMismatchException e) {
                        System.out.println("Please Enter an Integer : " + e);
                        sc.nextLine();
                    }
                }
                textday.setText("");
                textmonth.setText("");
                textyear.setText("");
            }
        });

        Pane root = new Pane();
        root.getChildren().add(imageView);
        root.getChildren().add(table_content);
        root.getChildren().add(btn1);
        root.getChildren().add(btn2);
        root.getChildren().add(btn3);
        root.getChildren().add(btn4);
        root.getChildren().add(btn5);
        root.getChildren().add(day);
        root.getChildren().add(month);
        root.getChildren().add(year);
        root.getChildren().add(textday);
        root.getChildren().add(textmonth);
        root.getChildren().add(textyear);
        root.getChildren().add(status);
        root.getChildren().add(winnerbtn);
        Scene scene = new Scene(root, 1250, 500);

        //Second new tab added new Columns

        TableColumn<Object, String> team_A_Column = new TableColumn<>("Team A Name");
        team_A_Column.setCellValueFactory(new PropertyValueFactory<>("team_X_name"));
        team_A_Column.setMinWidth(205);

        TableColumn<Object, String> team_B_Column = new TableColumn<>("Team B Name");
        team_B_Column.setCellValueFactory(new PropertyValueFactory<>("team_Y_name"));
        team_B_Column.setMinWidth(205);

        TableColumn<Object, Integer> team_A_GoalColumn = new TableColumn<>("Team A\nGoals");
        team_A_GoalColumn.setCellValueFactory(new PropertyValueFactory<>("team_X_GoalCount"));
        team_A_GoalColumn.setMinWidth(55);

        TableColumn<Object, Integer> team_B_GoalColumn = new TableColumn<>("Team B\nGoals");
        team_B_GoalColumn.setCellValueFactory(new PropertyValueFactory<>("team_Y_GoalCount"));
        team_B_GoalColumn.setMinWidth(55);

        TableColumn<Object, Date> date_Column = new TableColumn<>("Date");
        date_Column.setCellValueFactory(new PropertyValueFactory<>("date"));
        date_Column.setMinWidth(105);

        //text field for the date Search
        TextField search_tf = new TextField();
        search_tf.setPromptText("YYYY-MM-DD");
        search_tf.setLayoutX(300);
        search_tf.setLayoutY(25);
        search_tf.setStyle(
                "-fx-text-fill: #654321;"+
                        "-fx-border-color: #FFB6C1;"+
                        "-fx-font-weight: bold;");


        //label for the date calling "played match date"
        Label date_label = new Label("Played Match Date :");
        date_label.setLayoutX(150);
        date_label.setLayoutY(25);
        date_label.setStyle("-fx-font-weight: bold;"+
                "-fx-text-fill: #654321;");

        //Button for sorting the date
        Button sort_btn = new Button("Sort");
        sort_btn.setLayoutX(350);
        sort_btn.setLayoutY(300);
        sort_btn.setPrefSize(100, 30);
        sort_btn.setStyle("-fx-background-color: #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-font-weight: bold;");
        sort_btn.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                sort_btn.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        sort_btn.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                sort_btn.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        sort_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                date_Column.setSortType(TableColumn.SortType.ASCENDING);
                table_content1.getSortOrder().addAll(date_Column);
            }
        });

        //Button to go to the previous page -back
        Button back_btn = new Button("Back");
        back_btn.setLayoutX(100);
        back_btn.setLayoutY(300);
        back_btn.setPrefSize(100, 30);
        back_btn.setStyle("-fx-background-color: #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-font-weight: bold;");
        back_btn.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                back_btn.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        back_btn.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                back_btn.setStyle("-fx-background-color:#FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        back_btn.setOnAction(e -> primaryStage.setScene(scene));

        //Button for clearing up the current search
        Button clear_btn = new Button("Clear");
        clear_btn.setLayoutX(25);
        clear_btn.setLayoutY(80);
        clear_btn.setPrefSize(100, 30);
        clear_btn.setStyle("-fx-background-color:#FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-font-weight: bold;");
        clear_btn.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                clear_btn.setStyle("-fx-background-color: #FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        clear_btn.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                clear_btn.setStyle("-fx-background-color:#FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        clear_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for (int o = 1; o <= 2; o++) {
                    for (int n = 0; n < table_content1.getItems().size(); n++) {
                        table_content1.getItems().clear();
                    }
                    observableList2.addAll(num_match);
                    table_content1.setItems(observableList2);
                    search_tf.setText("");

                }
            }
        });

        //Button to search the mention played Date match team goals
        Button search_btn = new Button("Search");
        search_btn.setLayoutX(25);
        search_btn.setLayoutY(25);
        search_btn.setPrefSize(100, 30);
        search_btn.setStyle("-fx-background-color: #FFB6C1;" +
                "-fx-text-fill: #654321;" +
                "-fx-font-weight: bold;");
        search_btn.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                search_btn.setStyle("-fx-background-color:#FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        search_btn.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                search_btn.setStyle("-fx-background-color:#FFB6C1;" +
                        "-fx-text-fill: #654321;" +
                        "-fx-font-weight: bold;");
            }
        });
        //the EventHandler Action when the key is pressed,the console will also print the word pressed when its been pressed
        search_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("pressed searched button");
                int b = 0;
                int c = 0;
                LocalDate findLocalDate = LocalDate.parse(search_tf.getText());
                for (Match match  : num_match) {
                    if (match.getDate().getDate().equals(findLocalDate)){
                        observableList3.addAll(num_match.get(c));
                        table_content1.setItems(observableList3);
                        b++;
                    }
                    c++;
                }
                if (b==0) {
                    Alert alert4 = new Alert(Alert.AlertType.INFORMATION);
                    alert4.setTitle("Information Dialog");
                    alert4.setHeaderText("Error Information");
                    alert4.setContentText("Date Not Found !!!");

                    alert4.showAndWait();
                }
            }
        });


        table_content1.setLayoutX(540);
        table_content1.setLayoutY(25);
        table_content1.getColumns().addAll(team_A_Column, team_B_Column, team_A_GoalColumn, team_B_GoalColumn, date_Column);

        Pane root1 = new Pane();
        root1.getChildren().add(imageView1);
        root1.getChildren().add(table_content1);
        root1.getChildren().add(back_btn);
        root1.getChildren().add(search_tf);
        root1.getChildren().add(search_btn);
        root1.getChildren().add(clear_btn);
        root1.getChildren().add(sort_btn);
        root1.getChildren().add(date_label);

        scene1 = new Scene(root1, 1250, 500);


        primaryStage.setScene(scene);
        primaryStage.show();
    }



    public static void main(String[] args) {
        launch(args);

    }
}

