package com.company;

public class FootballClub extends SportsClub implements Comparable<FootballClub>{

    private int win_count;
    private int draws_count;
    private int defeats_count;
    private int scoredGoal_count;
    private int receivedGoal_count;
    private int current_point;
    private int playedMatch_count;
    private int difference_Goal;


    public int getWin_count() {
        return win_count;
    }

    public void setWin_count(int f_count) {
        win_count = f_count;
    }

    public int getDraws_count() {
        return draws_count;
    }

    public void setDraws_count(int f_count) {
        draws_count = f_count;
    }

    public int getDefeats_count() {
        return defeats_count;
    }

    public void setDefeats_count(int f_count) {
        defeats_count = f_count;
    }

    public int getScoredGoal_count() {
        return scoredGoal_count;
    }

    public void setScoredGoal_count(int f_count) {
        scoredGoal_count = f_count;
    }

    public int getReceivedGoal_count() {
        return receivedGoal_count;
    }

    public void setReceivedGoal_count(int f_count) {
        receivedGoal_count = f_count;
    }

    public int getCurrent_point() {
        return current_point;
    }

    public void setCurrent_point(int f_count) {
        current_point = f_count;
    }

    public int getPlayedMatch_count() {
        return playedMatch_count;
    }

    public void setPlayedMatch_count(int f_count) {
        playedMatch_count = f_count;
    }

    public int getDifference_Goal() {
        return difference_Goal;
    }

    public void setDifference_Goal(int difference_Goal) {
        this.difference_Goal = difference_Goal;
    }


    @Override
    public int compareTo(FootballClub o) {
        int a = o.difference_Goal - this.difference_Goal;
        int b = o.current_point - this.current_point;
        return a+b ;
    }
}

