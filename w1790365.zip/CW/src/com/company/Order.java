package com.company;

import java.util.Comparator;

public class Order implements Comparator<FootballClub> {


    @Override
    public int compare(FootballClub t_one, FootballClub t_two) {

        if(t_one.getCurrent_point() > t_two.getCurrent_point())
            return -1;
        else
            if (t_one.getCurrent_point() < t_two.getCurrent_point())
                return 1;
            else{
                int final_goal1 = t_one.getScoredGoal_count() - t_one.getReceivedGoal_count();
                int final_goal2 = t_two.getScoredGoal_count() - t_two.getReceivedGoal_count();
                if(final_goal1 >final_goal2)
                    return -1;
                else
                    if(final_goal1 < final_goal2)
                        return 1;
                    else return 0;

            }
    }
}
